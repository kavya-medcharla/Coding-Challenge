using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BenefitsCalculator.Models;
using BenefitsCalculator.Services;
using Newtonsoft.Json;

using BenefitsCalculator.Services.Interfaces;

namespace BenefitsCalculator.Pages
{
    public class PreviewCostModel : PageModel
    {
        public BenefitCost BenefitCost { get; set; }

        public void OnGet()
        {
            // Retrieve the employee from TempData
            Employee employee = new Employee();

            if (TempData.TryGetValue("Employee", out var employeeValue))
            {
                var employeeJson = employeeValue.ToString();
                employee = JsonConvert.DeserializeObject<Employee>(employeeJson);
            }
            //Employee employee = TempData.ContainsKey("Employee")?(Employee)TempData["Employee"]: null;
            // Calculate the benefit cost
            IEmployeeBenefits benefitCostService = new PaylocityBenefits();
            BenefitCost = benefitCostService.CalculateBenefitCost(employee);
        }
        }
}
