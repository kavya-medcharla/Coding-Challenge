using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BenefitsCalculator.Models;
using Newtonsoft.Json;
using BenefitsCalculator.Services.Interfaces;

namespace BenefitsCalculator.Pages
{
    public class AddEmployeeModel : PageModel
    {
        [BindProperty]
        public Employee Employee { get; set; }
        private readonly IEmployeeService _employeeService;

        public AddEmployeeModel(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }
        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var employeeJson = JsonConvert.SerializeObject(Employee);
            TempData["Employee"] = employeeJson;
            //TempData["Employee"] = Employee;
            Employee.EmployeeId = Guid.NewGuid();
           await _employeeService.CreateEmployee(Employee);
            return null;
        }

        public IActionResult OnPostSaveDetails()
        {
            // method logic here
            return null;
        }

        public IActionResult OnPostPreviewCost()
        {
            // method logic here
            return null;
        }
    }
}
