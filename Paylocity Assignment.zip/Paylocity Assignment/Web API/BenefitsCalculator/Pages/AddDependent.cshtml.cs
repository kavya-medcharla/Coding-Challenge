using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BenefitsCalculator.Models;
using Newtonsoft.Json;

namespace BenefitsCalculator.Pages
{
    public class AddDependentModel : PageModel
    {
        [BindProperty]
        public Dependent Dependent { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPostAdd()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Retrieve the employee from TempData
            //Employee employee = TempData.ContainsKey("Employee") ? (Employee)TempData["Employee"] : null;
            Employee employee = new Employee();
            
            if (TempData.TryGetValue("Employee", out var employeeValue))
            {
                var employeeJson = employeeValue.ToString();
                employee = JsonConvert.DeserializeObject<Employee>(employeeJson);
            }

            // Add the dependent to the employee
            employee.Dependents.Add(Dependent);

            // Save the employee back to TempData
            var employeeWithDependentsJson = JsonConvert.SerializeObject(employee);
            TempData["Employee"] = employeeWithDependentsJson;

            return RedirectToPage("AddDependent");
        }
        public IActionResult OnPostPreview()
        {
            //Employee employee = new Employee();

            //if (TempData.TryGetValue("Employee", out var employeeValue))
            //{
            //    var employeeJson = employeeValue.ToString();
            //    employee = JsonConvert.DeserializeObject<Employee>(employeeJson);
            //}

            //// Add the dependent to the employee
            //employee.Dependents.Add(Dependent);

            //// Save the employee back to TempData
            //var employeeWithDependentsJson = JsonConvert.SerializeObject(employee);
            //TempData["Employee"] = employeeWithDependentsJson;

            // Redirect to the PreviewCost page
            return RedirectToPage("PreviewCost");
        }
    }
}
