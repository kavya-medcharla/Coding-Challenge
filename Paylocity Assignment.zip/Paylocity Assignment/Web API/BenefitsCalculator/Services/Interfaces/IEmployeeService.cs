﻿using BenefitsCalculator.Models;

namespace BenefitsCalculator.Services.Interfaces
{
    public interface IEmployeeService
    {
        Task CreateEmployee(Employee employee);
        Task<IEnumerable<Employee>> SearchEmployeeAsync(string searchString);
    }
}
