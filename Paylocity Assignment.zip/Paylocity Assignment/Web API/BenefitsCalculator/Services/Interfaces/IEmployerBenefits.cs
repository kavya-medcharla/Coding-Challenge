﻿using BenefitsCalculator.Models;

namespace BenefitsCalculator.Services.Interfaces
{
    public interface IEmployeeBenefits
    {
        BenefitCost CalculateBenefitCost(Employee employee);
    }
}
