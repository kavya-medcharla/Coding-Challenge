﻿using BenefitsCalculator.Models;
using BenefitsCalculator.Services.Interfaces;
using Newtonsoft.Json;

namespace BenefitsCalculator.Services
{
    public class EmployeeApiService:IEmployeeService
    {
        private readonly HttpClient _httpClient;
        public EmployeeApiService(HttpClient httpClient)
        {
            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("https://localhost:7175");
            //HttpResponse resposne = _httpClient.GetAsync("https://localhost:7175/Employee/3FA85F64-5717-4562-B3FC-2C963F66AFA6");
            ////HttpClient client = new HttpClient();

            //resposne.EnsureSuccessStatusCode();
            //string responseBody = await resposne.Content.ReadAsStringAsync();
        }
        public async Task<IEnumerable<Employee>> SearchEmployeeAsync(string searchString)
        {
            var response = await _httpClient.GetAsync("https://localhost:7175/Employee/3FA85F64-5717-4562-B3FC-2C963F66AFA6");
            response.EnsureSuccessStatusCode();

            var content = await response.Content.ReadAsStringAsync();
            var employees = JsonConvert.DeserializeObject<IEnumerable<Employee>>(content);

            return employees;
        }
        public async Task CreateEmployee(Employee employee)
        {
            //var response = await _httpClient.GetAsync("https://localhost:7175/Employee/3FA85F64-5717-4562-B3FC-2C963F66AFA6");
            //response.EnsureSuccessStatusCode();
            var response = await _httpClient.PostAsJsonAsync("https://localhost:7175/Employee", employee);
            response.EnsureSuccessStatusCode();
            return;
        }
    }
}
