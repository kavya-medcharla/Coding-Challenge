﻿using BenefitsCalculator.Models;
using BenefitsCalculator.Services.Interfaces;

namespace BenefitsCalculator.Services
{
    public class PaylocityBenefits : IEmployeeBenefits
    {
        private const decimal EmployeeBaseCost = 1000m;
        private const decimal DependentBaseCost = 500m;
        private const decimal NameDiscount = 0.1m;

        //public PaylocityBenefits(IEmployeeService service = null)
        //{
        //    this.Service = service;
        //}
        public BenefitCost CalculateBenefitCost(Employee employee)
        {
            decimal employeeCost = CalculateCost(EmployeeBaseCost, employee.FirstName);
            decimal dependentsCost = employee.Dependents.Sum(dependent => CalculateCost(DependentBaseCost, dependent.FirstName));
            decimal totalCost = employeeCost + dependentsCost;

            return new BenefitCost
            {
                EmployeeId = employee.EmployeeId,
                EmployeeCost = employeeCost,
                DependentsCost = dependentsCost,
                TotalCost = totalCost
            };
        }

        private decimal CalculateCost(decimal baseCost, string firstName)
        {
            bool hasDiscount = firstName.StartsWith("A", StringComparison.OrdinalIgnoreCase);
            return baseCost * (hasDiscount ? 1 - NameDiscount : 1);
        }
    }
}
