﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;


namespace BenefitsCalculator.Models
{
    public class Employee
    {
        public Guid EmployeeId { get; set; }
        [DisplayName("First Name")]
        [Required]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "First Name should contain only alphabets.")]
        public string FirstName { get; set; }
        [DisplayName("Last Name")]
        [Required]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Last Name should contain only alphabets.")]
        public string LastName { get; set; }
        public List<Dependent> Dependents { get; set; } = new List<Dependent>();
    }
}
