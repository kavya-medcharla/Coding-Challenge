﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
namespace BenefitsCalculator.Models
{
    public class Dependent
    {
        public int Id { get; set; }
        
        [DisplayName("First Name")]
        [Required]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "First Name should contain only alphabets.")]
        public string FirstName { get; set; }
        
        [DisplayName("Last Name")]
        [Required]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Last Name should contain only alphabets.")]
        public string LastName { get; set; }
        public int EmployeeId { get; set; }
    }
}
