﻿using Microsoft.Data.Sqlite;
namespace EmployeeWebAPI.Data
{
    public class SqliteContext
    {
        private readonly string _connectionString;
        public SqliteContext(string connectionString)
        {
            _connectionString = connectionString;
        }
        public SqliteConnection CreateConnection()
        {
            return new SqliteConnection(_connectionString);
        }
    }
}
