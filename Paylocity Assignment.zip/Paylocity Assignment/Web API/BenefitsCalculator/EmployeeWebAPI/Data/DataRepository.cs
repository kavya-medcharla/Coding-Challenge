﻿using EmployeeWebAPI.DataModels;
using Microsoft.Data.Sqlite;

namespace EmployeeWebAPI.Data
{
    public class DataRepository
    {
        private readonly SqliteContext _context;

        public DataRepository(SqliteContext context)
        {
            _context = context;
        }

        public void AddEmployeeData(Employee employee)
        {
            using (var connection = _context.CreateConnection())
            {
                connection.Open();
                using(var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        using (var command = connection.CreateCommand())
                        {
                            command.CommandText = "INSERT INTO Employee (first_name, last_name, salary, employeeID) VALUES (@firstName,@lastName,@salary,@empID)";
                            command.Parameters.AddWithValue("@firstName", employee.FirstName);
                            command.Parameters.AddWithValue("@lastName", employee.LastName);
                            command.Parameters.AddWithValue("@salary", employee.Salary);
                            command.Parameters.AddWithValue("@empID", employee.EmployeeId);

                            var result = command.ExecuteNonQuery();
                        }
                        foreach (var dependentObj in employee.Dependents)
                        {
                            using (var command = connection.CreateCommand())
                            {
                                command.CommandText = "INSERT INTO Dependent(first_name, last_name, employeeId) VALUES (@firstName,@lastName,@employeeID)";
                                command.Parameters.AddWithValue("@firstName", dependentObj.FirstName);
                                command.Parameters.AddWithValue("@lastName", dependentObj.LastName);
                                command.Parameters.AddWithValue("@employeeID", employee.EmployeeId);
                                var result = command.ExecuteNonQuery();
                            }
                        }
                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                    }
                }
            }
        }

        public Employee GetEmployeeById(string empID)
        {
            using (var connection = _context.CreateConnection())
            {
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT first_name,last_name, employeeID FROM Employee WHERE employeeID= @id";
                    command.Parameters.AddWithValue("@id", empID);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            var employee = new Employee
                            {
                                FirstName = reader.GetString(0),
                                LastName = reader.GetString(1),
                                EmployeeId = new Guid(reader.GetString(2))
                            };
                            return employee;
                        }
                    }
                }
            }
            return null;
        }

        public List<Dependent> GetEmployeeDependents(string empID)
        {
            var result = new List<Dependent>();
            using (var connection = _context.CreateConnection())
            {
                connection.Open();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT first_name,last_name FROM Dependent WHERE employeeId = @id";
                    command.Parameters.AddWithValue("@id", empID);

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var dependent = new Dependent
                            {
                                FirstName = reader.GetString(0),
                                LastName = reader.GetString(1)
                            };
                            result.Add(dependent);
                        }
                    }
                }
            }
            return result;
        }

        public async Task<IEnumerable<Employee>> SearchEmployeesAsync(string searchText)
        {
            List<Employee> employees = new List<Employee>();
            using (var connection = _context.CreateConnection())
            {
                await connection.OpenAsync();

                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT first_name,last_name,employeeID FROM Employee WHERE first_name LIKE @searchTerm OR last_name LIKE @searchTerm";
                    command.Parameters.AddWithValue("@searchTerm", $"%{searchText}%");
                    using (var reader = await command.ExecuteReaderAsync())
                    {
                        while (await reader.ReadAsync())
                        {
                            var employee = new Employee
                            {
                                FirstName = reader.GetString(0),
                                LastName = reader.GetString(1),
                                EmployeeId = Guid.Parse(reader.GetString(2))
                            };
                            employees.Add(employee);
                        }
                    }
                }
            }
            return employees;
        }
    }
}
