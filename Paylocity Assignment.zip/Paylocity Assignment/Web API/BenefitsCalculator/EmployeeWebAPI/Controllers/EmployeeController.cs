using EmployeeWebAPI.Data;
using Microsoft.AspNetCore.Mvc;
using EmployeeWebAPI.DataModels;

namespace EmployeeWebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly ILogger<EmployeeController> _logger;
        private readonly DataRepository _repository;
        public EmployeeController(ILogger<EmployeeController> logger, DataRepository dataRepository)
        {
            _logger = logger;
            _repository = dataRepository;
        }

        [HttpPost]
        public IActionResult InsertEmployeeData(Employee employeeData)
        {
            _repository.AddEmployeeData(employeeData);
            return Ok();
        }

        [HttpGet("{empId}")]
        public IActionResult GetEmployeeById(string empId)
        {
            var employee = _repository.GetEmployeeById(empId);

            if (employee == null)
            {
                return NotFound();
            }

            return Ok(employee);
        }

        [HttpGet("{empId}/Dependents")]
        public IActionResult GetEmployeeDependents(string empId)
        {
            var dependents = _repository.GetEmployeeDependents(empId);

            if (dependents == null)
            {
                return NotFound();
            }

            return Ok(dependents);
        }

        [HttpGet("/search/{searchText}")]
        public async Task<ActionResult<IEnumerable<Employee>>> SearchEmployees(string searchText)
        {
            var employees = await _repository.SearchEmployeesAsync(searchText);

            if (employees == null)
            {
                return NotFound();
            }

            return Ok(employees.ToList());
        }
    }
}