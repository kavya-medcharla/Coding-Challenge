﻿namespace EmployeeWebAPI.DataModels
{
    public class Employee
    {
        public Guid EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal Salary { get; set; }

        public List<Dependent>? Dependents { get; set; }
    }
}
