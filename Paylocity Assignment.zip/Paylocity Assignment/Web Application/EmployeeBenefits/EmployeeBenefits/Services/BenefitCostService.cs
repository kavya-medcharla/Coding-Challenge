﻿using EmployeeBenefits.Models;
using EmployeeBenefits.Services.Interfaces;

namespace EmployeeBenefits.Services
{
    public class PaylocityBenefits : IEmployeeBenefits
    {
        private const decimal EMPLOYEEBASECOST = 1000m;
        private const decimal DEPENDENTBASECOST = 500m;
        private const decimal NAMEDISCOUNT = 0.1m;
        private const decimal TOTALPAYCHECKS = 26;
        public BenefitCost CalculateBenefitCost(Employee employee)
        {
            decimal employeeCost = CalculateCost(EMPLOYEEBASECOST, employee.FirstName);
            decimal dependentsCost = employee.Dependents != null && employee.Dependents.Any()? employee.Dependents.Sum(dependent => CalculateCost(DEPENDENTBASECOST, dependent.FirstName)):0;
            decimal totalCost = employeeCost + dependentsCost;

            return new BenefitCost
            {
                EmployeeId = employee.EmployeeId,
                EmployeeCost = employeeCost,
                DependentsCost = dependentsCost,
                TotalCost = totalCost,
                CostPerPaycheck = totalCost/TOTALPAYCHECKS,
            };
        }

        private decimal CalculateCost(decimal baseCost, string firstName)
        {
            bool hasDiscount = firstName.StartsWith("A", StringComparison.OrdinalIgnoreCase);
            return baseCost * (hasDiscount ? 1 - NAMEDISCOUNT : 1);
        }
    }
}
