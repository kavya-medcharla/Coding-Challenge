﻿using EmployeeBenefits.Models;

namespace EmployeeBenefits.Services.Interfaces
{
    public interface IEmployeeBenefits
    {
        BenefitCost CalculateBenefitCost(Employee employee);
    }
}
