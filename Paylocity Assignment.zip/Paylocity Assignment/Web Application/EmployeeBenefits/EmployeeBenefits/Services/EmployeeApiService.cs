﻿using EmployeeBenefits.Models;
using EmployeeBenefits.Services.Interfaces;
using Newtonsoft.Json;

namespace EmployeeBenefits.Services
{
    public class EmployeeApiService:IEmployeeService
    {
        private readonly HttpClient _httpClient;
        public EmployeeApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        public async Task<IEnumerable<Employee>> SearchEmployeeAsync(string searchString)
        {
            var response = await _httpClient.GetAsync("https://localhost:7175/search/"+searchString);
            response.EnsureSuccessStatusCode();
            var employees = await response.Content.ReadFromJsonAsync<IEnumerable<Employee>>();
            return employees;
        }
        public async Task CreateEmployee(Employee employee)
        {   
            var response = await _httpClient.PostAsJsonAsync("https://localhost:7175/Employee", employee);
            response.EnsureSuccessStatusCode();
            return;
        }
    }
}
