﻿using EmployeeBenefits.Models;
using EmployeeBenefits.Services.Interfaces;

namespace EmployeeBenefits.Utilities
{
    public static class EmployeeExtensions
    {
        public static EmployeeCostDetailsViewModel ToEmployeeCostDetailsViewModel(this Employee employee, IEmployeeBenefits benefits)
        {
            BenefitCost benefitCost = benefits.CalculateBenefitCost(employee);

            return new EmployeeCostDetailsViewModel
            {
                EmployeeId = employee.EmployeeId.ToString(),
                EmployeeName = $"{employee.FirstName} {employee.LastName}",
                CostPerPayCheck = benefitCost.CostPerPaycheck
            };
        }
        public static List<EmployeeCostDetailsViewModel> ToEmployeeCostDetailsViewModels(this List<Employee> employees, IEmployeeBenefits benefitsCalculator)
        {
            var employeeViewModels = new List<EmployeeCostDetailsViewModel>();

            foreach (var employee in employees)
            {
                employeeViewModels.Add(employee.ToEmployeeCostDetailsViewModel(benefitsCalculator));
            }

            return employeeViewModels;
        }
    }

}
