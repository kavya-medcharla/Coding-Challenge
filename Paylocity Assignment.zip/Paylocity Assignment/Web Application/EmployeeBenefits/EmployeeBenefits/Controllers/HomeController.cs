﻿using EmployeeBenefits.Services.Interfaces;
using EmployeeBenefits.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using EmployeeBenefits.Utilities;

namespace EmployeeBenefits.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IEmployeeService _employeeService;
        private readonly IEmployeeBenefits _paylocityBenefits;

        public HomeController(ILogger<HomeController> logger, IEmployeeService employeeService, IEmployeeBenefits employeeBenefits)
        {
            _logger = logger;
            _employeeService = employeeService;
            _paylocityBenefits = employeeBenefits;
        }

        public async Task<IActionResult> Index(string searchTerm)
        {
            if (!string.IsNullOrEmpty(searchTerm))
            {
                var results = await _employeeService.SearchEmployeeAsync(searchTerm);
               
                var employeeSearchViewModel = new EmployeeSearchViewModel() { Employees = results.ToList().ToEmployeeCostDetailsViewModels(_paylocityBenefits), SearchText = searchTerm };
                return View(employeeSearchViewModel);
            }
            return View(new EmployeeSearchViewModel());
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public async Task<IActionResult> OnPostSaveDetails(Employee employee)
        {
            if (!ModelState.IsValid)
            {
                return View(employee);
            }
            employee.EmployeeId = Guid.NewGuid();
            await _employeeService.CreateEmployee(employee);
            ViewBag.ShowDetails = true;
            return View("Employee", employee);
        }
        public IActionResult Employee()
        {
            ViewBag.ShowDetails = false;
            return View(new Employee());
        }
        public IActionResult PreviewCost(Employee employee)
        {
            var benefits = _paylocityBenefits.CalculateBenefitCost(employee);
            ViewBag.ShowCost = true;
            ViewData["Costs"] = benefits;
            return View("Employee",employee);
        }
    }
}