﻿namespace EmployeeBenefits.Models
{
    public class EmployeeCostDetailsViewModel
    {
        public string EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public decimal CostPerPayCheck { get; set; }
    }
}
