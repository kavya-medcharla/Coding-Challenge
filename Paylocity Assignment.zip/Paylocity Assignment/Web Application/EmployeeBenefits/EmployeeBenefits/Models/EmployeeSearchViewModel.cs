﻿namespace EmployeeBenefits.Models
{
    public class EmployeeSearchViewModel
    {
        public string SearchText { get; set; }
        public List<EmployeeCostDetailsViewModel> Employees { get; set; }
    }
}
